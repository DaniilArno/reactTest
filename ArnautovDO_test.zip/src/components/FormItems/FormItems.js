import React from 'react'

import './FormItems.css';
import Arrow from './btnArrow.png'

export default class FormItems extends React.Component {
  constructor() {
    super();
    
    this.state = { 
      name: '', 
      age: '', 
      price: '', 
      descr: '',
      radio: 'white',
      selectedOption: ''
    };
    this.onInputChange = this.onInputChange.bind(this);
    this.onCheckChange = this.onCheckChange.bind(this);
    this.onRadioChange = this.onRadioChange.bind(this);

  };
  onCheckChange(e) {
    this.setState({
      selectedOption: e.target.value
    })
  };
  onInputChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  };
  onRadioChange(e) {
    this.setState({
      radio: e.target.value
    });
  }

  render() {
    const { name, age, price, descr,  radio,selectedOption  } = this.state;
    const inputText = [
      {type: 'text',name: 'name',className: 'form__item form__item_title',
      placeholder: 'Название', value: `${name}`},
      {type: 'text',name: 'age',className: 'form__item form__item_age',
      placeholder: 'Год', value: `${age}`},
      {type: 'text',name: 'price',className: 'form__item form__item_price',
      placeholder: 'Цена', value: `${price}`},
      {type: 'text',name: 'descr',className: 'form__item form__item_descr',
      placeholder: 'Описание', value: `${descr}`},
    ];
    const inputItems = inputText.map( ({  type,name, className, placeholder,value }) => {
      return (
       <input key={name} type={type}
              name={name} className={className} 
              placeholder={placeholder} value={value} 
              onChange={this.onInputChange} />
      )
    });
    return (
    	<div>
        <div className="form__items">
            {inputItems}
        </div>
        <div className="form__items input-group">

        <label className="form__item form__item_radio">  
          <div className="form__item_label">
            Цвет  
          </div>         
          <input type="radio" 
                  value="white" 
                  className="form__item_Whitecolor"
                  checked={ radio === "white"}
                  onChange={this.onRadioChange} />
          <input type="radio" 
                  value="black"
                  className="form__item_Blackcolor"
                  checked={ radio === "black"}
                  onChange={this.onRadioChange}  />
          <input type="radio" 
                  value="gray"
                  className="form__item_color"
                  checked={ radio === "gray"}
                  onChange={this.onRadioChange}  />
          <input type="radio" 
                  value="red" 
                  className="form__item_color"
                  checked={ radio === "red"}
                  onChange={this.onRadioChange} />
          <input type="radio" 
                  value="green"
                  className="form__item_color"
                  checked={ radio === "green"}
                  onChange={this.onRadioChange}  />
				</label>
				<select value={selectedOption} onChange={this.onCheckChange}
								className="form__item form__item_age">
					<option  value="Статус">Статус</option>
					<option value="В наличии">В наличии</option>
					<option value="Ожидается">Ожидается</option>
					<option value="Нет в наличии">Нет в наличии</option>
				</select>
				<button  type="submit" className="btn btn-primary form__item form__item_btn">
					ОТПРАВИТЬ
					<img src={Arrow}    alt="Send" className="form__item_img"/>
				</button>
			</div>
    </div>
)
    
  }
};