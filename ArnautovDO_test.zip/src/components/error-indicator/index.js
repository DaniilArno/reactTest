import ErrorIndicator from './error-indicator';

export default ErrorIndicator;
